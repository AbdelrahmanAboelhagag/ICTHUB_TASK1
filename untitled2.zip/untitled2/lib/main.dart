import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return  MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: SafeArea(

          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Text(
                'Welcome ',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize:40,
                  color: Colors.blue,
                ),
              ),

              Image.network(
                'https://marketplace.canva.com/EAFNWqxhyug/1/0/1600w/canva-blue-and-white-simple-abstract-heart-pharmacy-logo-Jk68RNTJC_s.jpg'              ),
              Mycont(textt: 'Get Start', widthh: 225),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Mycont(textt: 'Sign up', widthh: 100),
                  SizedBox(
                    width: 20,
                  ),
                  Mycont(textt: 'Login', widthh: 100),
                ],
              )





            ],
          ),
        ),
      ),
    );
  }
}

class Mycont extends StatelessWidget {
  final String textt;
  final double widthh;
  const Mycont({super.key, required this.textt, required this.widthh});

  @override
  Widget build(BuildContext context) {
    return  Container(
      width: widthh,
      height: 75,
      color: Colors.blue,
      alignment: Alignment.center,
      child: Text(
        textt,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 25,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}