import 'package:flutter/material.dart';

class ListScreen extends StatelessWidget {
   ListScreen({super.key});
   List<int> myList=[1,2,3,4,5,6,7,8,9];
   @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        title:const Text('Choose activity'),
      ),
      body: ListView.separated(
        itemCount: myList.length,
          itemBuilder: (context,index),{
          return Column(
          children: [
            Divider(
          color: Colors.lightBlue,
      thickness: 5,
          )
          ],
          )
      },


      ),

    );
  }
}
