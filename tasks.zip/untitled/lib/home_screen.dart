import 'package:flutter/material.dart';
import 'package:untitled/Screen2.dart';


class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomescreenState();
}

class _HomescreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {

    return  Scaffold(
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [

                SizedBox(
                  width: 40,
                ),
                Text(
                  'Welcome',

                  style: TextStyle(
                    color: Colors.blue,

                    fontSize: 50,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            InkWell(
              onTap : (){
                setState(() {
                  Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) =>const screen2(
                        textk: 'Help',
                        scricon2: Icons.help,
                      ) ,
                      )
                  );
                }
                );
              },
              child: const contrs(txt: 'Help', iconn:Icons.help,sizedbox: 200, ),
            ),
            InkWell(
              onTap : (){
                setState(() {
                  Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) =>const screen2(
                        textk: 'Speaker',
                        scricon2: Icons.speaker,
                      ) ,
                      )
                  );
                }
                );
              },
              child: const contrs(txt: 'Speaker', iconn: Icons.speaker,sizedbox: 170,),
            ),
            InkWell(
              onTap : (){
                setState(() {
                  Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) =>const screen2(
                        textk: 'Mobile',
                        scricon2: Icons.mobile_friendly,
                      ) ,
                      )
                  );
                }
                );
              },
              child: const contrs(txt: 'Mobile', iconn: Icons.mobile_friendly,sizedbox: 180,),
            ),
            InkWell(
              onTap : (){
                setState(() {
                  Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) =>const screen2(
                        textk: 'Watches',
                        scricon2: Icons.watch,
                      ) ,
                      )
                  );
                }
                );
              },
              child: const contrs(txt: 'Watches', iconn: Icons.watch,sizedbox: 165,),
            ),
            InkWell(
              onTap : (){
                setState(() {
                  Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) =>const screen2(
                        textk: 'Tv',
                        scricon2: Icons.tv,
                      ) ,
                      )
                  );
                }
                );
              },
              child: const contrs(txt: 'Tv', iconn: Icons.tv,sizedbox: 220,),
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Container(
                  width: 100,
                  height: 50,
                  decoration:  BoxDecoration(
                    color: Colors.blue,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Icon(
                    Icons.rate_review,
                    color: Colors.white,
                  ),
                ),
              ],
            ),


          ]
        ),
      ),
    );
  }
}

class contrs extends StatelessWidget {
  final String txt;
  final IconData iconn;
  final double sizedbox;

  const contrs({super.key, required this.txt, required this.iconn, required this.sizedbox});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100,
      width: 300,
      alignment: Alignment.centerLeft,
      decoration: BoxDecoration(
        color: Colors.blue,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Icon(iconn),
          const SizedBox(
            width: 5,
          ),
          Text(
            txt,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(
            width: sizedbox,
          ),
          const Icon(Icons.arrow_forward_ios_sharp),
        ],
      ),
    );
  }
}