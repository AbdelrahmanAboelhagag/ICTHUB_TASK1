import 'package:flutter/material.dart';

class screen2 extends StatelessWidget {
  final String textk;
  final IconData scricon2;
  const screen2({super.key, required this.textk, required this.scricon2});

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(scricon2,
                  size: 50,
                ),
                Text(textk,
                  style: TextStyle(
                    fontSize: 70,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),

          ],
        ),
      ),
    );
  }
}